import math_utils
print("Choose an operation:")
print("1.Add")
print("2.Subtract")
print("3.Multiply")
print("4.Divide")
choice = input("Enter the operation choice(1-4):")
num1=float(input("Enter the first number:"))
num2=float(input("Enter the second number:"))
if choice=="1":
    result=math_utils.add(num1,num2)
    operation="Addition"
elif choice=="2":
    result=math_utils.subtract(num1,num2)
    operation="Subtraction"
elif choice=="3":
    result=math_utils.multiply(num1,num2)
    operation="Multiplication"
elif choice=="4":
    result=math_utils.divide(num1,num2)
    operation="Division"
else:
    result=None
    print("Not a valid choice!")
if result is not None:
    print((operation),"Result:",result)
