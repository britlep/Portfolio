def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

def multiply(a, b):
    return a * b

def divide(a, b):
    if b == 0:
        return "Cannot divide by zero!"
    return a / b

if __name__ == "__main__":
    
    print("Testing addition:9+4=",add(9,4))
    print("Testing subtraction:9-4=",subtract(9,4))  
    print("Testing multiplication:9*4=",multiply(9,4))
    print("Testing division:9/4=",divide(9,4))
   


   
