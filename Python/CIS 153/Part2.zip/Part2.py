def encode_message(message):
    encode= str.maketrans('AEIOUaeiou','EIOUAeioua') 
    return message[::-1].translate(encode)

def decode_message(message):
    encode=str.maketrans('AEIOUaeiou','UAEIOuaeio')
    return message[::-1].translate(encode)
    

message=input('What is the message?')
choose=input('Do you want to encode or decode?')

if choose=='encode':
    print ('The encoded message is:',encode_message(message))
elif choose=='decode':
    print('The decoded message is:', decode_message(message))
else:
    print('Error: Encode or Decode only!')
