import random
playlist=['Hello','Goodbye']

while True:
    print("1. View playlist")
    print("2. Add a song")
    print("3. Remove a song")
    print("4. Shuffle playlist")
    print("5. Sort playlist alphabetically")
    print("6. Quit")

    choice=input("Choose an option (1-6):")

    if choice=="1":
        print("Your playlist:",playlist)

    elif choice=="2":
        song=input("Enter a song to add:")
        playlist.append(song)
        print(song,"was added to your playlist.")
        print("Updated playlist:",playlist)

    elif choice=="3":
        remove=input("Enter the name of a song to remove:")
        if remove in playlist:
            playlist.remove(remove)
            print(remove,"was removed.")
        else:
            print("That song is not in the playlist.")
        print("Updated playlist:",playlist)

    elif choice=="4":
        random.shuffle(playlist)
        print("Shuffled playlist:",playlist)

    elif choice=="5":
        playlist.sort()
        print("Sorted playlist:",playlist)

    elif choice=="6":
        print("Goodbye!")
        break
    
    else:
        print("Invalid choice. Please enter a number between 1 and 6.")
