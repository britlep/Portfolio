lablist=list()
while (True):
    num=input("Enter a number or type 'done' to finish:")
    if num == 'done':break
    try:
        number=float(num)
        lablist.append(number)
    except ValueError:
        print("Invalid input: Please enter a number.")
if lablist:
    print("Numbers entered:",lablist)
    print("Total sum:",sum(lablist))
    print("Count of numbers entered:",len(lablist))
    print("Average:",sum(lablist)/len(lablist))
    print("Largest number:",max(lablist))
    print("Smallest number:",min(lablist))
else:
    print("Need to enter numbers.")

#Reflection: I did not work in a group for this project.
#Rather than needing to schedule time with a group to complete the project on time, I instead chose to work on my own. 
#I chose to familiarize myself with the material before working on this assignmnet.
#I wanted to read the chapter before I set out to accomplish the tasks required of the assignmnet.
#After learning the material I was able to complete the assignment.
