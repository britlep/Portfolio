#Extra Credit Attempted
print('HW3: Improved Budget Calculator')
try:
    monthlyincome= float(input('How much is your monthly income?'))
    rent=float(input('How much is the rent payment?'))
    groceries=float(input('How much are groceries?'))
    utilities=float(input('How much are the utilities?'))
except ValueError:
 print('Error: Please enter a valid number.')
 quit()
totalexpenses=float(rent)+ float(groceries)+float(utilities)
print('Total expenses are',totalexpenses)
remainingbalance=float(monthlyincome)-float(totalexpenses)
print('Remaining balance is', remainingbalance)
if remainingbalance >0:
    print (f'You are on track! Your remaining balance is ${remainingbalance}.')
elif remainingbalance <0:
    print (f'Warning: You have exceeded your budget by ${float(totalexpenses)- float(monthlyincome)}!')
else:print ('You\'ve used your entire budget!')

