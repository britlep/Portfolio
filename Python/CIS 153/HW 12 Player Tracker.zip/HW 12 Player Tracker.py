#Part 1

#Step 1
class PartyAnimal:
   def __init__(self,z):
      self.x=0
      self.name=z
      print(self.name,"constructed")
   def party(self):
      self.x=self.x+1
      print(self.name,"party count",self.x)
   def __del__(self):
      print(self.name,"was destroyed")
s=PartyAnimal("Sally")
s.party()
j=PartyAnimal("Jim")
j.party()
s.party()
del j

#Step 2
class PartyAnimal:
   count=0
   def __init__(self,z):
      self.x=0
      self.name=z
      print(self.name,"entered the party.")
   def party(self):
      PartyAnimal.count +=1
      print("Total number of party animals:",PartyAnimal.count)
   def __del__(self):
      PartyAnimal.count -=1
      print(self.name,"left the party.")
      print("Number of party animals still partying:",PartyAnimal.count)
print("Total number of party animals:",PartyAnimal.count)
c=PartyAnimal("STEM Club")
c.party()
b=PartyAnimal("Brit")
b.party()
l=PartyAnimal("Lisa")
l.party()
del c
d=PartyAnimal("CIS Department")
d.party()
print("Directory of object d",dir(d))
print("Type of object d",type(d))

#Part 2

#Step 1
class Player:
   def __init__(self,z):
      self.points=0
      self.levels=1
      self.name=z
      print(self.name,"entered the game.")
   def point(self):
      self.points += 1
      print(self.name,"scored a point!")
   def score(self):
      print("The score for",self.name,"is:",self.points)
   def level(self):
         if self.points >=5:
          self.levels +=1
         print("The level for",self.name,"is:",self.levels)
   def __del__(self):
      self.points -= 1
      print(self.name,"quit the game!")

#Step 2
o=Player("Bob")
t=Player("Jane")
th=Player("Jon")
f=Player("Mary")
o.point()
th.point()
o.point()
o.point()
f.point()
th.point()
t.point()
o.point()
o.point()
del t
f.point()
f.point()
o.score()
th.score()
f.score()
o.level()
th.level()
f.level()

#Step 3
print("Type of class Player:",type(Player))
print("Type of object o:",type(o))
print("Directory of class Player:",dir(Player))
print("Directory of object o:",dir(o))

#Reflection Questions
#1. A class describes what something is and what it can do and an object uses the class to do something.
#2. It accesses and modifies the objects attributes.
#3. It helps keep things organized and effecient.
#4. Type tells you what kind of object it is and dir show the attributes and methods of the object.

      


